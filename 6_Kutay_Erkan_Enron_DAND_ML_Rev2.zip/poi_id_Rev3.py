
# coding: utf-8

# # Identifying Enron Fraud with Machine Learning
# #### by Kutay Erkan

# In[2]:

# importing os and adding working directory

import os
os.chdir("..\\final_project")


# In[3]:

# importing necessary packages and functions

import sys
import pickle

import matplotlib.pyplot as plt

# appending tools folder

sys.path.append("..\\tools\\")

from tester import dump_classifier_and_data

from feature_format import featureFormat
from feature_format import targetFeatureSplit


# In[4]:

# opening the dataset

data_dict = pickle.load(open("final_project_dataset.pkl", "r") )

# In[5]:

print "Number of people:", len(list(data_dict))

print "Number of features:", len(data_dict.values()[0])

# counting POIs

i = 0
for person in data_dict:
    if data_dict[person]['poi'] == True:
        i+=1
print "Number of POI's:", i

print "Sample names of people (dictionary keys):\n"
print list(data_dict)[0:5], "...\n"

print "Sample attributes for the person 'METTS MARK':\n"
print data_dict['METTS MARK']

# In[6]:

# inital plot
    
features = ["salary", "bonus"]

data = featureFormat(data_dict, features)

for point in data:
    salary = point[0]
    bonus = point[1]
    plt.scatter( salary, bonus )

plt.xlabel("salary")
plt.ylabel("bonus")
plt.show();

# In[7]:

# removing outliers and irrelevant data points

features = ["salary", "bonus"]
data_dict.pop('TOTAL', 0)
data_dict.pop('THE TRAVEL AGENCY IN THE PARK', 0)
data_dict.pop('LOCKHART, EUGENE E', 0)
data = featureFormat(data_dict, features)

for point in data:
    salary = point[0]
    bonus = point[1]
    plt.scatter( salary, bonus )

plt.xlabel("salary")
plt.ylabel("bonus")
plt.show();

# In[8]:

my_dataset = data_dict # for testing purposes
    
# print possible outliers

for key in data_dict:
    if data_dict[key]['salary'] != 'NaN' and data_dict[key]['bonus'] != 'NaN':
        if data_dict[key]['salary'] > 600000 or data_dict[key]['bonus'] > 5000000:
            print key

# In[9]:

# defining a function to compute new features

def computeFraction( poi_messages, all_messages ):
    
    fraction = 0
    
    if poi_messages != "NaN" and all_messages != "NaN" and all_messages != 0:
        fraction = float(poi_messages) / all_messages
    else:
        return 0

    return fraction

# In[10]:

# adding new features to data dictionary

for name in data_dict:

    data_point = data_dict[name]

    
    from_poi_to_this_person = data_point["from_poi_to_this_person"]
    to_messages = data_point["to_messages"]
    fraction_from_poi = computeFraction( from_poi_to_this_person, to_messages )
    data_point["fraction_from_poi"] = fraction_from_poi


    from_this_person_to_poi = data_point["from_this_person_to_poi"]
    from_messages = data_point["from_messages"]
    fraction_to_poi = computeFraction( from_this_person_to_poi, from_messages )
    data_point["fraction_to_poi"] = fraction_to_poi

# In[11]:

# splitting into features and labels

features_list = ["poi", "from_messages", "to_messages", "from_poi_to_this_person", "from_this_person_to_poi",
                 "fraction_from_poi", "fraction_to_poi", "salary", "bonus", "total_payments",
                 "deferral_payments", "expenses", "deferred_income", "long_term_incentive",
                 "restricted_stock_deferred", "shared_receipt_with_poi", "loan_advances",
                 "director_fees", "total_stock_value", "restricted_stock", "exercised_stock_options", "other"]

data_array = featureFormat( data_dict, features_list )
labels, features = targetFeatureSplit(data_array)

# creating training and test sets

from sklearn.model_selection import train_test_split

features_train, features_test, labels_train, labels_test = train_test_split(features, labels, test_size=0.25, random_state=42)

# In[12]:

# scaling the features

from sklearn.preprocessing import MinMaxScaler

min_max_scaler = MinMaxScaler()
features_train_minmax = min_max_scaler.fit_transform(features_train)
features_test_minmax = min_max_scaler.fit_transform(features_test)

# In[13]:

# importing modules and creating RFECV

# from sklearn.svm import SVC
from sklearn import tree
# from sklearn.model_selection import StratifiedKFold
from sklearn.feature_selection import RFECV

# svc = SVC(kernel='linear')
clf_dt = tree.DecisionTreeClassifier(random_state=0)

# rfecv = RFECV(estimator=svc, step=1, cv=StratifiedKFold(labels_train), scoring='accuracy')
rfecv = RFECV(estimator=clf_dt, step=1, cv=None, scoring='accuracy')

temp = rfecv.fit(features_train, labels_train)


# In[14]:

# print features

print("Optimal number of features : %d" % rfecv.n_features_)
print rfecv.ranking_

i=0
index_list=[]
for i in range(len(rfecv.ranking_)):
    if rfecv.ranking_[i]==1:
        index_list.append(features_list[i+1])
print "Use these features:", index_list

# plot number of features VS. cross-validation scores

plt.figure()
plt.xlabel("Number of features selected")
plt.ylabel("Cross validation score (nb of correct classifications)")
plt.plot(range(1, len(rfecv.grid_scores_) + 1), rfecv.grid_scores_)
plt.show();

# In[15]:

# splitting into features and labels, using new features_list

features_list = ['poi', 'from_this_person_to_poi', 'fraction_to_poi', 'deferral_payments',
                 'expenses', 'deferred_income', 'long_term_incentive', 'restricted_stock_deferred',
                 'shared_receipt_with_poi', 'loan_advances', 'director_fees', 'total_stock_value',
                 'exercised_stock_options', 'other']

data_array = featureFormat( data_dict, features_list )
labels, features = targetFeatureSplit(data_array)

# creating training and test sets

from sklearn.model_selection import train_test_split

features_train, features_test, labels_train, labels_test = train_test_split(features, labels, test_size=0.3, random_state=42)


# In[16]:

# scaling the features, using new_features_list

from sklearn.preprocessing import MinMaxScaler

min_max_scaler = MinMaxScaler()
features_train_minmax = min_max_scaler.fit_transform(features_train)
features_test_minmax = min_max_scaler.fit_transform(features_test)

# In[17]:

# importing sklearn modules

from sklearn import tree # already imported before, but is here too for readability
from sklearn.naive_bayes import GaussianNB
from sklearn import linear_model


# importing sklearn metrics

from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score


# defining a scores function to evaluate algorithms

def scores(name, labels, predictions):
    accuracy = round(accuracy_score(labels, predictions), 2)
    precision = round(precision_score(labels, predictions), 2)
    recall = round(recall_score(labels, predictions), 2)
    f1 = round(f1_score(labels, predictions), 2)
    
    print name
    print "Accuracy:", accuracy
    print "Recall:", recall
    print "Precision:", precision
    print "F1 Score:", f1


# In[20]:

import warnings
warnings.filterwarnings('ignore')

# defining different algorithms

clf_tree = tree.DecisionTreeClassifier(random_state=0)
clf_NB = GaussianNB()
reg = linear_model.LogisticRegression()

# fitting algorithms with a variable assigned to stop unwanted output

temp1 = clf_tree.fit(features_train_minmax, labels_train)
temp2 = clf_NB.fit(features_train_minmax, labels_train)
temp3 = reg.fit(features_train_minmax, labels_train)

# predicting and printing results

pred_clf_tree = clf_tree.predict(features_test_minmax)
pred_clf_NB = clf_NB.predict(features_test_minmax)
pred_reg = reg.predict(features_test_minmax)

print "Test set size:", len(labels_test)
print " "
scores("Decision Tree", labels_test, pred_clf_tree)
print " "
scores("GaussianNB", labels_test, pred_clf_NB)
print " "
scores("Logistic Regression", labels_test, pred_reg)

# In[19]:

# defining different algorithms

clf_tree = tree.DecisionTreeClassifier(criterion= "entropy", min_samples_leaf=4, random_state=0)
clf_NB = GaussianNB(priors=[0.95, 0.05])
reg = linear_model.LogisticRegression()

# param_grid = {'C': [0.001, 0.01, 0.1, 1, 10, 100, 1000] }
# reg = GridSearchCV(reg, param_grid)

# fitting algorithms with a variable assigned to stop unwanted output

temp1 = clf_tree.fit(features_train_minmax, labels_train)
temp2 = clf_NB.fit(features_train_minmax, labels_train)
temp3 = reg.fit(features_train_minmax, labels_train)

# predicting and printing results

pred_clf_tree = clf_tree.predict(features_test_minmax)
pred_clf_NB = clf_NB.predict(features_test_minmax)
pred_reg = reg.predict(features_test_minmax)

print "Test set size:", len(labels_test)
print " "
scores("Decision Tree", labels_test, pred_clf_tree)
print " "
scores("GaussianNB", labels_test, pred_clf_NB)
print " "
scores("Logistic Regression", labels_test, pred_reg)

clf = clf_tree
dump_classifier_and_data(clf, my_dataset, features_list)

