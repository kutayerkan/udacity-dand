Python scripts used in the project, in order:
* mapparser.py
* tags.py
* audit.py
* data.py
* csv_to_db.py
* query_db.py

Link to OSM file:
* https://mapzen.com/data/metro-extracts/metro/boston_massachusetts/

References:
* https://udacity.com/
* https://stackoverflow.com/questions/2511679/python-number-of-rows-affected-by-cursor-executeselect
* https://stackoverflow.com/questions/2887878/importing-a-csv-file-into-a-sqlite3-database-table-using-python
* https://stackoverflow.com/questions/38610723/pandas-insert-dataframe-into-database
* https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.to_sql.html
* https://stackoverflow.com/questions/3425320/sqlite3-programmingerror-you-must-not-use-8-bit-bytestrings-unless-you-use-a-te
* https://stackoverflow.com/questions/21883119/how-to-count-number-of-records-in-an-sql-database-with-python
* https://www.techonthenet.com/sql/union.php
* https://maps.google.com/localguides/
* http://wiki.openstreetmap.org/wiki/Good_practice