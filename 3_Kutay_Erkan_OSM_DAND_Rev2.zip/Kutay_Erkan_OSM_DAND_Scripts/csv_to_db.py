# -*- coding: utf-8 -*-
"""
Created on Tue Oct 03 13:22:46 2017

@author: 26022308
"""

import sqlite3
import pandas as pd

con = sqlite3.connect("boston_MA.db")
con.text_factory = str


df = pd.read_csv("nodes.csv")
df.to_sql("nodes", con, if_exists='replace', index=False)

df = pd.read_csv("nodes_tags.csv")
df.to_sql("nodes_tags", con, if_exists='replace', index=False)

df = pd.read_csv("ways.csv")
df.to_sql("ways", con, if_exists='replace', index=False)

df = pd.read_csv("ways_nodes.csv")
df.to_sql("ways_nodes", con, if_exists='replace', index=False)

df = pd.read_csv("nodes.csv")
df.to_sql("ways_tags", con, if_exists='replace', index=False)

con.commit()
con.close()