# -*- coding: utf-8 -*-

import sqlite3

con = sqlite3.connect("boston_MA.db")
cur = con.cursor()

def number_of_unique_users():
	result = cur.execute('SELECT COUNT(DISTINCT(u.uid)) \
    FROM \
    (SELECT uid FROM nodes \
    UNION SELECT uid FROM ways) u;')
	return result.fetchone()[0]

def number_of_nodes():
	result = cur.execute('SELECT COUNT(*) FROM nodes')
	return result.fetchone()[0]

def number_of_ways():
	result = cur.execute('SELECT COUNT(*) FROM ways')
	return result.fetchone()[0]

def number_of_libraries():
    result = cur.execute('SELECT COUNT(*) AS num \
                         FROM nodes_tags \
                         WHERE nodes_tags.value = "library";')
    return result.fetchone()[0]

def top_10_amenities():
    result = cur.execute('SELECT value, COUNT(*) AS num \
                         FROM nodes_tags \
                         WHERE nodes_tags.key = "amenity" \
                         GROUP BY value \
                         ORDER BY num DESC;')
    data = result.fetchall()[:10]
    amenities = [i[0] for i in data]
    values = [j[1] for j in data]
    import pandas as pd
    df = pd.DataFrame(list(zip(amenities, values)), \
              columns=['Amenities', '# of Amenities'])
    df = df.reset_index(drop=True)
    return df


print "Number of unique users: " , number_of_unique_users()
print "Number of nodes: " , number_of_nodes()
print "Number of ways: " , number_of_ways()
print "Number of libraries: " , number_of_libraries()
print "Top 10 Amenities: \n", top_10_amenities()





